#!/bin/bash
adduser --disabled-password --gecos '' player1
chpasswd <<<'player1:dc5411'
adduser --disabled-password --gecos '' player2
chpasswd <<<'player2:dc5411'
/etc/init.d/apache2 start
/etc/init.d/ssh start
ruby /root/boss.rb