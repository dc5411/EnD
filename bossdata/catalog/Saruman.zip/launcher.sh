#!/bin/bash
adduser --disabled-password --gecos '' player1
chpasswd <<<'player1:dc5411'
adduser --disabled-password --gecos '' player2
chpasswd <<<'player2:dc5411'
adduser --disabled-password --gecos '' player3
chpasswd <<<'player3:dc5411'

echo '127.0.0.1 palantir' >> /etc/hosts

echo 'ALL ALL=NOPASSWD: /bin/nano' >> /etc/sudoers

/etc/init.d/apache2 start
/etc/init.d/ssh start
ruby /root/boss.rb
